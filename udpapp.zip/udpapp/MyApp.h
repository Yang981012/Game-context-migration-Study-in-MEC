//Created by Yang Hu in the university of Bristol
//Thesis: Game context migration study for MEC
//Date: 12th/Sep/2021
#ifndef INET_APPLICATIONS_UDPAPP_MYAPP_H_
#define INET_APPLICATIONS_UDPAPP_MYAPP_H_

#include "UdpBasicApp.h"

namespace inet {

class MyApp: public UdpBasicApp
{
protected:
    //State = 0 means "STOP" state
    //State = 1 means "SEND" state
    //State = 2 means "CLOSE" state
    int State;
    //IdentifySet = 0 means end user
    //IdentifySet = 1 means MEC server
    int IdentifySet;

    std::vector<L3Address> CommunicationAddresses;
    std::vector<std::string> CommunicationAddressStr;

protected:
    virtual void initialize(int stage);

    virtual void processStart();
    virtual void processStop();
    virtual void processSend();
    virtual void processPacket(Packet *msg);

    virtual L3Address chooseCommunicationAddr();
    virtual void sendCommunicationPacket();

    virtual void sendPacket();
    virtual void handleMessageWhenUp(cMessage *msg);
public:
    MyApp();
    virtual ~MyApp();
};

} /* namespace inet */

#endif /* INET_APPLICATIONS_UDPAPP_MYAPP_H_ */
