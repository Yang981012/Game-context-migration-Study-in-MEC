//Created by Yang Hu in the university of Bristol
//Thesis: Game context migration study for MEC
//Date: 12th/Sep/2021
#include "MyApp.h"
#include "inet/networklayer/common/L3AddressResolver.h"
#include "inet/applications/base/ApplicationPacket_m.h"
#include "inet/common/packet/Packet.h"
#include "inet/networklayer/common/FragmentationTag_m.h"
#include "inet/common/TimeTag_m.h"

namespace inet {

MyApp::MyApp() {
    // TODO Auto-generated constructor stub

}

MyApp::~MyApp() {
    // TODO Auto-generated destructor stub
}
/*
 *initialize() is called in parameters initialize
 */
void MyApp::initialize(int stage){
    ApplicationBase::initialize(stage);

    if (stage == INITSTAGE_LOCAL) {
        numSent = 0;
        numReceived = 0;
        WATCH(numSent);
        WATCH(numReceived);

        localPort = par("localPort");
        destPort = par("destPort");
        startTime = par("startTime");
        stopTime = par("stopTime");
        packetName = par("packetName");
        dontFragment = par("dontFragment");
        State = par("State");
        IdentifySet = par("IdentifySet");
        if (stopTime >= SIMTIME_ZERO && stopTime < startTime)
            throw cRuntimeError("Invalid startTime/stopTime parameters");
        selfMsg = new cMessage("sendTimer");
    }
}
/*
 *handlesMessageWhenUp is called when receiving msg, no matter selfMsg or other Msg
 *Application uses selfMsg to adjust its state
 *and use socket.processMessage() to handle msg from other others
 *socket.processMessage() is build in Socket.h and it calls socketDateArrived() (socketDateArrived() is not rebuild in MyApp.cc. It can be find in UdpBasicApp.cc)
 */
void MyApp::handleMessageWhenUp(cMessage *msg)
{
    if (msg->isSelfMessage()) {
        ASSERT(msg == selfMsg);
        switch (selfMsg->getKind()) {
            case START:
                processStart();
                break;

            case SEND:
                processSend();
                break;

            case STOP:
                processStop();
                break;

            default:
                throw cRuntimeError("Invalid kind %d in self message", (int)selfMsg->getKind());
        }
    }
    else
        socket.processMessage(msg);
}
/*
 * ProcessStart() is used to get the initial destination address
 */
void MyApp::processStart() {
    socket.setOutputGate(gate("socketOut"));
    const char *localAddress = par("localAddress");
    socket.bind(*localAddress ? L3AddressResolver().resolve(localAddress) : L3Address(), localPort);
    setSocketOptions();

    const char *destAddrs = par("destAddresses");
    cStringTokenizer tokenizer(destAddrs);
    const char *token;

    while ((token = tokenizer.nextToken()) != nullptr) {
        destAddressStr.push_back(token);
        L3Address result;
        L3AddressResolver().tryResolve(token, result);
        if (result.isUnspecified())
            EV_ERROR << "cannot resolve destination address: " << token << endl;
        destAddresses.push_back(result);
    }

    const char *CommunicationAddrs = par("CommunicationAddresses");
    cStringTokenizer tokenizer1(CommunicationAddrs);
    const char *token1;

    while ((token1 = tokenizer1.nextToken()) != nullptr) {
        CommunicationAddressStr.push_back(token1);
        L3Address result;
        L3AddressResolver().tryResolve(token1, result);
        if (result.isUnspecified())
            EV_ERROR << "cannot resolve destination address: " << token1 << endl;
        CommunicationAddresses.push_back(result);
    }


    if (!destAddresses.empty() && State == 1) {
        selfMsg->setKind(SEND);
        processSend();
    }
    else {
        if (stopTime >= SIMTIME_ZERO) {
            selfMsg->setKind(STOP);
            scheduleAt(stopTime, selfMsg);
        }
    }
}

/*
 * ProcessStop() is used in "Stop" state
 */
void MyApp::processStop(){
    simtime_t d = simTime() + par("sendInterval");
    if(stopTime < SIMTIME_ZERO || d < stopTime){
        if(State == 0){
            selfMsg->setKind(STOP);
            scheduleAt(d, selfMsg);
        }else if(State == 1){
            selfMsg->setKind(SEND);
            scheduleAt(d, selfMsg);
        }else if(State == 2){
            socket.close();
        }
    }else{
        socket.close();
    }
}

/*
 * processSend() has three parts:
 * sendPacket() is called to send a message
 * sendCommunicationPacket() is used to broadcast update when Identify = 1
 * Identify = 1 means this application is in MEC server
 * Identify = 0 means this applicaiton is end user and end user would start a clock after send request
 * This clock could be used in reconnection and preventing request loss
 */

void MyApp::processSend(){
    sendPacket();
    if(IdentifySet == 1) sendCommunicationPacket();
    if(IdentifySet == 0){
        simtime_t index = 10;
        simtime_t d = simTime() + index * par("sendInterval");
        State = 1;
        selfMsg->setKind(SEND);
        scheduleAt(d, selfMsg);
    }
}

/*
 * The first thing is cancelEvent(), it can cancel the reconnection clock
 * if there is no clock, no influence
 * PakcetState = 0 means this message is a request
 * PacketState = 1 means this message is a update
 * PacketState can be get by packet->peekData<ApplicationPacket>()->getPacketState()
 */
void MyApp::processPacket(Packet *pk){
    cancelEvent(selfMsg);
    emit(packetReceivedSignal, pk);
    EV_INFO << "Received packet: " << UdpSocket::getReceivedPacketInfo(pk) << endl;
    int NewState = pk->peekData<ApplicationPacket>()->getSequenceNumber();
    if(pk->peekData<ApplicationPacket>()->getPacketState() == 0 && IdentifySet == 1)
    {
        processSend();
        numReceived++;
        numSent++;
        State = 0;
        selfMsg->setKind(STOP);
    }else if(pk->peekData<ApplicationPacket>()->getPacketState() == 1 && IdentifySet == 1)
    {
        numReceived = NewState + 1;
        numSent = NewState + 1;
        State = 0;
    }else if(pk->peekData<ApplicationPacket>()->getPacketState() == 1 && IdentifySet == 0)
    {
        if(NewState == numSent){
            simtime_t d = simTime() + par("sendInterval");
            numSent++;
            State = 1;
            selfMsg->setKind(SEND);
            scheduleAt(d, selfMsg);
        }else{
            simtime_t d = simTime() + par("sendInterval");
            State = 1;
            selfMsg->setKind(SEND);
            scheduleAt(d, selfMsg);
        }
    }
    delete pk;
}

/*
 * a sending function
 * use ApplicationPacket as payload
 * Application is a kind of Message, which has been modified in this project, not same as original INET framework
 * It can be find in inet/applications/base/ApplicationPacket.msg
 */
void MyApp::sendPacket(){
    std::ostringstream str;
    str << packetName << "-" << numSent;
    Packet *packet = new Packet(str.str().c_str());
    if(dontFragment)
        packet->addTag<FragmentationReq>()->setDontFragment(true);
    const auto& payload = makeShared<ApplicationPacket>();
    payload->setPacketState(IdentifySet);
    payload->setChunkLength(B(par("messageLength")));
    payload->setSequenceNumber(numSent);
    payload->addTag<CreationTimeTag>()->setCreationTime(simTime());
    packet->insertAtBack(payload);
    L3Address destAddr = chooseDestAddr();
    emit(packetSentSignal, packet);
    socket.sendTo(packet, destAddr, destPort);
}
/*
 * get broadcasting address
 */
L3Address MyApp::chooseCommunicationAddr()
{
    int k = intrand(CommunicationAddresses.size());
    if (CommunicationAddresses[k].isUnspecified() || CommunicationAddresses[k].isLinkLocal()) {
        L3AddressResolver().tryResolve(CommunicationAddressStr[k].c_str(), CommunicationAddresses[k]);
    }
    return CommunicationAddresses[k];
}

/*
 * broadcasting packets to all other servers
 */
void MyApp::sendCommunicationPacket()
{
    std::ostringstream str;
    str << packetName << "-" << numSent;
    Packet *packet = new Packet(str.str().c_str());
    if(dontFragment)
        packet->addTag<FragmentationReq>()->setDontFragment(true);
    const auto& payload = makeShared<ApplicationPacket>();
    payload->setPacketState(IdentifySet);
    payload->setChunkLength(B(par("messageLength")));
    payload->setSequenceNumber(numSent);
    payload->addTag<CreationTimeTag>()->setCreationTime(simTime());
    packet->insertAtBack(payload);
    L3Address destAddr = chooseCommunicationAddr();
    emit(packetSentSignal, packet);
    socket.sendTo(packet, destAddr, destPort);
}

Define_Module(MyApp);

} /* namespace inet */

